import logo from './logo.svg';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css'
import './App.css';
import  Swap from './swap/swap'
import Form from './form/form';
function App() {
  return (
    <div className="App">
      <Swap />
      {/* <Form/> */}
    </div>
  );
}

export default App;
